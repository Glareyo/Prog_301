﻿namespace SportsLibrary
{
    public interface ISport
    {
        string Name { get; set; }
        string Description { get; set; }
    }
}
