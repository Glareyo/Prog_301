﻿namespace SportsLibrary
{
    public interface IRepo
    {

    }
}
