﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsLibrary.Sports
{
    public class MMA : Sport
    {
        public MMA()
        {
            Name = "MMA Combat Sport";
            Description = "A Sport based around combat.";
        }
    }
}
